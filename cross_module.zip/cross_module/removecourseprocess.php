<?php
  require_once('dbconnect.php');
  $connect = mysqli_connect( HOST, USER, PASS, DB ) or die("Can not connect");

  if(isset($_GET['c_id']) && isset($_GET['c_sem']) && 
  !empty($_GET['c_id']) && !empty($_GET['c_sem'])){
	  	$c_id = $_GET['c_id'];
	  	$c_sem = $_GET['c_sem'];

	  	$result = mysqli_query($connect, "DELETE FROM croos_module WHERE $c_id =c_id and
		$c_sem = c_sem") or die("Can not execute query");
  }
?>
