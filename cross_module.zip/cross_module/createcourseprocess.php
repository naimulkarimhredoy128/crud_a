<?php
  require_once('dbconnect.php');
  $connect = mysqli_connect( HOST, USER, PASS, DB ) or die("Can not connect");

  if(isset($_GET['cid']) && isset($_GET['c_dept']) && isset($_GET['sem']) && !empty($_GET['c_id']) && !empty($_GET['dep']) && 
  !empty($_GET['c_sem'])){
	  	$c_id = $_GET['c_id'];
	  	$c_dept = $_GET['c_dept'];
	  	$c_sem = $_GET['c_sem'];

	  	$result = mysqli_query($connect, "INSERT INTO croos_module (c_id, c_dept, c_sem) VALUES ('$c_id','$c_dept','$c_sem')") 
		or die("Can not execute query");
  }
?>