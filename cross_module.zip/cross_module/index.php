<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Menu Page</title>
</head>
<body>
	<div>
		<h1>Cross module Menu</h1>
		<a href=createcourse.php>Create a course</a><br>
		<a href=removecourse.php>Remove a course</a><br>
		<a href=addteacher.php>Add a Teacher to a course</a><br>
		<a href=removeteacher.php>Remove a Teacher from a course</a>
	</div>
</body>
</html>