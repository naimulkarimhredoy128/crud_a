<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Document</title>
</head>
<body>
	<div>
		<h1>Cross module Function</h1>
		<a href=createcourse.php>create Course To Semester</a><br>
		<a href=removecourse.php>remove Course From Semester</a><br>
		<a href=addcoursetoteacher.php>add Teacher to a course</a><br>
		<a href=removeteacher.php>remove Teacher from a course</a>
	</div>
</body>
</html>