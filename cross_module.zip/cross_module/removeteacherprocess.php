<?php
  require_once('dbconnect.php');
  $connect = mysqli_connect( HOST, USER, PASS, DB ) or die("Can not connect");

  if(isset($_GET['c_id']) && isset($_GET['t_id']) &&
  !empty($_GET['c_id']) && !empty($_GET['t_id'])){
	  	$c_id = $_GET['c_id'];
	  	$t_id = $_GET['t_id'];

	  	$result = mysqli_query($connect, "DELETE FROM croos_module WHERE $c_id =c_id and $t_id = t_id") 
		or die("Can not execute query");
  }
?>
