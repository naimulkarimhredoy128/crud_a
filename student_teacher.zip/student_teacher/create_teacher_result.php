<?php
    include("config.php");
  
	 $t_dept = $_GET['t_dept'];
	  $t_name = $_GET['t_name'];
	   $t_nid = $_GET['t_nid'];
	    $t_birth = $_GET['t_birth'];
    $t_address = $_GET['t_address'];
    $query = "INSERT INTO teacher VALUES(NULL,'$t_dept','$t_name', '$t_nid' ,'$t_birth' ,'$t_address')";
    $con->exec($query);

    echo "Record inserted:<br> t_dept = $t_dept <br> t_name=$t_name <br> t_nid=$t_nid <br> t_birth=$t_birth <br> t_address=$t_address";



	echo "<p><a href=read_teacher.php>READ all records</a>";
?>