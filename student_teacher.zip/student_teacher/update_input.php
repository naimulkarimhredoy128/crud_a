<?php
    include('config.php');
    $id = $_GET['id'];
    $query = "SELECT * FROM student WHERE id = '$id'";
    $returnobj = $con->query($query);
    $obj = $returnobj->fetch();

    ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Update</title>
        </head>
        <body>
            <h1>Update Record</h1>
            <form action="update_result.php" method="GET">
                <input type=hidden name=id value="<?php echo $id; ?>">
                <p>
                    dept: <input type=text name=dept value="<?php echo $obj['dept'];?>" required> <br>
                </p>
				<p>
                    name: <input type=text name=name value="<?php echo $obj['name'];?>" required> <br>
                </p>
				<p>
                    nid: <input type=text name=nid value="<?php echo $obj['nid'];?>" required> <br>
                </p>
				<p>
                    birth: <input type=text name=birth value="<?php echo $obj['birth'];?>" required> <br>
                </p>

                <p>
                    
                    address: <input type=text name=address value="<?php echo $obj['address'];?>" required> <br>
                </p>

                <p>
                    <input type=submit value=Update>
                </p>
            </form>
        </body>
        </html>
    <?php
?>