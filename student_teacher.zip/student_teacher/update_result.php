<?php
    include("config.php");
    $dept = $_GET['dept'];
    $name = $_GET['name'];
	$nid = $_GET['nid'];
    $birth = $_GET['birth'];
	$address = $_GET['address'];
	$id = $_GET['id'];

    $query = "UPDATE student SET dept='$dept', name='$name',nid='$nid',birth='$birth',address='$address' WHERE id='$id'";
    $con->exec($query);

    echo  $query;

    echo "<p>Record updated:<br> dept = $dept <br> name = $name <br> nid=$nid <br> birth=$birth <br> address=$address";



	echo "<p><a href=read.php>READ all records</a>";
?>