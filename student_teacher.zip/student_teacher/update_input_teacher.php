<?php
    include('config.php');
    $t_id = $_GET['t_id'];
    $query = "SELECT * FROM teacher WHERE t_id = '$t_id'";
    $returnobj = $con->query($query);
    $obj = $returnobj->fetch();

    ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Update</title>
        </head>
        <body>
            <h1>Update Record</h1>
            <form action="update_result.php" method="GET">
                <input type=hidden name=id value="<?php echo $id; ?>">
                <p>
                    t_dept: <input type=text name=t_dept value="<?php echo $obj['t_dept'];?>" required> <br>
                </p>
				<p>
                    t_name: <input type=text name=t_name value="<?php echo $obj['t_name'];?>" required> <br>
                </p>
				<p>
                    t_nid: <input type=text name=t_nid value="<?php echo $obj['t_nid'];?>" required> <br>
                </p>
				<p>
                    t_birth: <input type=text name=t_birth value="<?php echo $obj['t_birth'];?>" required> <br>
                </p>

                <p>
                    
                    t_address: <input type=text name=t_address value="<?php echo $obj['t_address'];?>" required> <br>
                </p>

                <p>
                    <input type=submit value=Update>
                </p>
            </form>
        </body>
        </html>
    <?php
?>