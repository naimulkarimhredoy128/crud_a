<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Input</title>
</head>
<body>
    <h1>Create Student Record</h1>
    <form action="create_result.php" method="GET">
        
		<p>
            dept: <input type=text name=dept required> <br>
        </p>
        <p>
            name: <input type=text name=name required> <br>
        </p>
		<p>
            nid: <input type=text name=nid required> <br>
        </p>
		<p>
            birth: <input type=text name=birth required> <br>
        </p>

        <p>
            
            address: <input type=text name=address required> <br>
        </p>

        <p>
            <input type=submit value=Insert>
        </p>
    </form>
</body>
</html>