<?php
    include('config.php');
    $query = "SELECT * FROM student";
    $retunobj = $con->query($query);
    $table = $retunobj->fetchAll();
    ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>ALL Table</title>
        </head>
        <body>
            <table>
                <table border>
                    <thead>
                        <th>id</th>
                        <th>dept</th>
						<th>name</th>
						<th>nid</th>
						<th>birth</th>
						<th>address</th>
                        <th>Delete</th>
                        <th>Update</th>
                    </thead>
                    <tbody>
                        <?php
                            foreach ($table as $student) {
                                ?>
                                <tr>
                                    <td><?php echo $student['id'];?></td>
									<td><?php echo $student['dept'];?></td>
									<td><?php echo $student['name'];?></td>
									<td><?php echo $student['nid'];?></td>
									<td><?php echo $student['birth'];?></td>
                                    <td><?php echo $student['address'];?></td>
                                    <td><a href="delete.php?id=<?php echo $student['id'];?>">Delete</a></td>
                                    <td><a href="update_input.php?id=<?php echo $student['id'];?>">Update</a></td>
                                </tr>
                                <?php
                            }
                        ?>
                    </tbody>
            </table>
            <br>
            <a href="create_input.php">Create a new record</a>
        </body>
        </html>
    <?php
?>