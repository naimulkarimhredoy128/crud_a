<?php
    include("config.php");
  
	 $dept = $_GET['dept'];
	  $name = $_GET['name'];
	   $nid = $_GET['nid'];
	    $birth = $_GET['birth'];
    $address = $_GET['address'];
    $query = "INSERT INTO student VALUES(NULL,'$dept','$name', '$nid' ,'$birth' ,'$address')";
    $con->exec($query);

    echo "Record inserted:<br> dept = $dept <br> name=$name <br> nid=$nid <br> birth=$birth <br> address=$address";



	echo "<p><a href=read.php>READ all records</a>";
?>