<?php
    include("config.php");
    $t_id = $_GET['t_id'];
    $query = "DELETE FROM teacher WHERE t_id='$t_id'";
    $con->exec($query);

    echo "Record deleted<br>";



	echo "<p><a href=read_teacher.php>READ all records</a>";
?>
