<?php
    include("config.php");
    $id = $_GET['id'];
    $query = "DELETE FROM student WHERE id='$id'";
    $con->exec($query);

    echo "Record deleted<br>";



	echo "<p><a href=read.php>READ all records</a>";
?>
