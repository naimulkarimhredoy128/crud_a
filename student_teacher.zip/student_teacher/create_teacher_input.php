<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Input</title>
</head>
<body>
    <h1>Create Teacher Record</h1>
    <form action="create_teacher_result.php" method="GET">
        
		<p>
            t_dept: <input type=text name=t_dept required> <br>
        </p>
        <p>
            t_name: <input type=text name=t_name required> <br>
        </p>
		<p>
            t_nid: <input type=text name=t_nid required> <br>
        </p>
		<p>
            t_birth: <input type=text name=t_birth required> <br>
        </p>

        <p>
            
            t_address: <input type=text name=t_address required> <br>
        </p>

        <p>
            <input type=submit value=Insert>
        </p>
    </form>
</body>
</html>