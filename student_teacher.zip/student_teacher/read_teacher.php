<?php
    include('config.php');
    $query = "SELECT * FROM teacher";
    $retunobj = $con->query($query);
    $table = $retunobj->fetchAll();
    ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>ALL Table</title>
        </head>
        <body>
            <table>
                <table border>
                    <thead>
                        <th>t_id</th>
                        <th>t_dept</th>
						<th>t_name</th>
						<th>t_nid</th>
						<th>t_birth</th>
						<th>t_address</th>
                        <th>Delete</th>
                        <th>Update</th>
                    </thead>
                    <tbody>
                        <?php
                            foreach ($table as $teacher) {
                                ?>
                                <tr>
                                    <td><?php echo $teacher['t_id'];?></td>
									<td><?php echo $teacher['t_dept'];?></td>
									<td><?php echo $teacher['t_name'];?></td>
									<td><?php echo $teacher['t_nid'];?></td>
									<td><?php echo $teacher['t_birth'];?></td>
                                    <td><?php echo $teacher['t_address'];?></td>
                                    <td><a href="delete_teacher.php?id=<?php echo $teacher['t_id'];?>">Delete</a></td>
                                    <td><a href="update_input_teacher.php?id=<?php echo $teacher['t_id'];?>">Update</a></td>
                                </tr>
                                <?php
                            }
                        ?>
                    </tbody>
            </table>
            <br>
            <a href="create_teacher_input.php">Create a new record</a>
        </body>
        </html>
    <?php
?>