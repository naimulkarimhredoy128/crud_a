<?php
    include("config.php");
    $t_dept = $_GET['t_dept'];
    $t_name = $_GET['t_name'];
	$t_nid = $_GET['t_nid'];
    $t_birth = $_GET['t_birth'];
	$t_address = $_GET['t_address'];
	$t_id = $_GET['t_id'];

    $query = "UPDATE teacher SET t_dept='$t_dept', t_name='$t_name',t_nid='$t_nid',t_birth='$t_birth',t_address='$t_address' WHERE t_id='$t_id'";
    $con->exec($query);

    echo  $query;

    echo "<p>Record updated:<br> t_dept = $t_dept <br> t_name = $t_name <br> t_nid=$t_nid <br> t_birth=$t_birth <br> t_address=$t_address";



	echo "<p><a href=read_teacher.php>READ all records</a>";
?>